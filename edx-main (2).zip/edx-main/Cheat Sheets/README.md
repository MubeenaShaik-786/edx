This folder contains cheatsheets for Data Science. If anyone wants to add more, they can send a PR.
